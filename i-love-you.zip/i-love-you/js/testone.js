function kdongy() {
  var y = document.getElementById("test");
  y.style.top = Math.random() * 500 + "px";
  y.style.left = Math.random() * 1100 + "px";
}

function dongy() {
  var co = document.getElementById("test");
  co.style.display = "none";
}

function okok() {
  var okk = document.getElementById("test");
  okk.style.display = "block";
}
